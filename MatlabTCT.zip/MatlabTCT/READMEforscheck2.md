This is scheck 1.2 such that it compiles with a modern GCC.

I just followed the compiler warnings and errors until it compiled. I hope this will be of use to someone.
The output of the Tests are cryptic to me but I hope to document it for the future.

The original authors can be found in README.html but are mentioned here as well:

Timo Latvala. Efficient Model Checking of Safety Properties. In: T. Ball and S.K. Rajamani (eds.), Model Checking Software. 10th International SPIN Workshop. Volume 2648 of LNCS, pp. 74-88, Springer, 2003.

-- Johan Sjölén


2020-10-23  
Build complete environments
```
Windows10
Cygwin
gcc v10
g++ v10
```