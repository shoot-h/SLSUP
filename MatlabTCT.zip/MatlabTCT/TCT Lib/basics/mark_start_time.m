% merge running information into MAKEIT.TXT in unified format
function mark_start_time()


% the end